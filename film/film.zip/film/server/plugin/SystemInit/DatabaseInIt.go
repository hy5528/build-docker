package SystemInit

import "server/model/system"

// TableInIt 初始化 mysql 数据库相关数据
func TableInIt() {
	// 创建 User Table
	system.CreateUserTable()
	// 初始化管理员账户
	system.InitAdminAccount()
	// 创建 Search Table
	system.CreateSearchTable()
	// 创建 MovieDetails Table
	system.CreateMovieDetailTable()
	// 创建 SlaveMovieInfo Table
	system.CreateSlaveMovieInfoTable()
	// 创建图片信息管理表
	system.CreateFileTable()
	// 创建采集失效记录表
	system.CreateFailureRecordTable()
}
